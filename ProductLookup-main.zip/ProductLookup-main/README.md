# Product Lookup
Product search for testing purposes.
Returns up to 100 test records

Full API: https://mockend.com/AndreaRichardson/ProductLookup/Repair

Query API: https://mockend.com/AndreaRichardson/ProductLookup/Repair?product_contains=TH&country_eq=IT&language_eq=se
